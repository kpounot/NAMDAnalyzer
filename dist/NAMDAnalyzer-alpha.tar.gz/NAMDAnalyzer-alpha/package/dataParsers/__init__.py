__all__ = [ "dcdParser",
            "logParser",
            "pdbParser",
            "psfParser",
            "velParser"]
