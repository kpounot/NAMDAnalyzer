from distutils.core import setup, Extension


with open('README.md', 'r') as f:
    description = f.read()


packagesList = [    'package',
                    'package.dataManipulation',
                    'package.dataParsers',
                    'package.dataConverters',
                    'package.helpersFunctions',
                    'package.test'  ]

setup(  name='NAMDAnalyzer',
        version='alpha',
        description=description,
        author='Kevin Pounot',
        author_email='kpounot@hotmail.fr',
        url='github.com/kpounot/NAMDAnalyzer',
        packages=packagesList   )

